window.YTD.tweets.part0 = [
    {
      "tweet": {
        "created_at": "Wed Jan 11 08:00:00 +0000 2023",
        "full_text": "A beautiful sunrise this morning! Every day is a new opportunity to chase our dreams. #MorningMotivation #Sunrise",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Sun Feb 05 10:30:00 +0000 2023",
        "full_text": "Enjoying a peaceful Sunday morning with a good book and a cup of coffee. Life is good. #SundayVibes #Relaxation",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Thu Mar 09 15:45:00 +0000 2023",
        "full_text": "Spent the afternoon hiking and reconnecting with nature. There's so much beauty in the world! #NatureLover #HikingAdventures",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Mon Apr 17 13:15:00 +0000 2023",
        "full_text": "Had a great workout today! Feeling strong and energized. Remember, health is wealth. #FitnessJourney #HealthyLiving",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Sat May 20 20:30:00 +0000 2023",
        "full_text": "Spending time with family tonight. Cherish these moments, they are the true treasures of life. #FamilyTime #Gratitude",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Tue Jun 13 11:20:00 +0000 2023",
        "full_text": "Started a new hobby today! It's never too late to learn something new. Stay curious and keep exploring. #NewHobby #LifelongLearning",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Fri Jul 07 17:50:00 +0000 2023",
        "full_text": "Had a delicious homemade dinner tonight. Cooking can be such a joyful and therapeutic activity. #CookingJoy #HomemadeMeal",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Mon Aug 28 14:10:00 +0000 2023",
        "full_text": "Helping a neighbor today reminded me of the power of community. Small acts of kindness make a big difference. #CommunityLove #Kindness",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Thu Sep 14 09:05:00 +0000 2023",
        "full_text": "Morning jogs are the best way to start the day! Fresh air and a clear mind. #MorningRun #HealthyHabits",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Sun Oct 29 18:25:00 +0000 2023",
        "full_text": "Just finished a wonderful movie night with friends. Great stories bring people together. #MovieNight #Friendship",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Fri Jan 06 07:15:00 +0000 2023",
        "full_text": "There's nothing like starting the day with a smile and a positive attitude. Let's make today amazing! #PositiveVibes #GoodMorning",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Wed Feb 01 12:45:00 +0000 2023",
        "full_text": "Had a wonderful conversation with an old friend. It's the little moments that count. #Friendship #Grateful",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Sat Mar 18 09:30:00 +0000 2023",
        "full_text": "Sunny days always bring so much joy and energy. Let's soak up the sunshine! #SunnyDay #Happiness",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Tue Apr 11 14:00:00 +0000 2023",
        "full_text": "Gardening is such a fulfilling hobby. Watching plants grow is like watching hope take root. #GardeningLife #Nature",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Mon May 08 18:45:00 +0000 2023",
        "full_text": "Finished a great book today. There's nothing like getting lost in a good story. #BookLover #Reading",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Thu Jun 15 11:10:00 +0000 2023",
        "full_text": "Cooking a new recipe tonight! Excited to try something different and delicious. #CookingExperiment #Foodie",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Sun Jul 23 15:20:00 +0000 2023",
        "full_text": "Taking a moment to appreciate the simple things in life. Gratitude changes everything. #SimplePleasures #Thankful",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Wed Aug 30 08:35:00 +0000 2023",
        "full_text": "Morning yoga session done. Feeling relaxed and ready to tackle the day. #YogaLife #Wellness",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Fri Sep 15 13:50:00 +0000 2023",
        "full_text": "Learning to play a new instrument is so rewarding. Every small progress feels like a big win. #MusicLover #NewSkills",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Tue Oct 10 19:05:00 +0000 2023",
        "full_text": "Spent the evening stargazing. The universe is truly magnificent. #Stargazing #Wonder",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Thu Nov 02 17:25:00 +0000 2023",
        "full_text": "Volunteering at the local shelter today. Helping others brings so much joy and fulfillment. #Volunteering #Community",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Mon Dec 11 20:30:00 +0000 2023",
        "full_text": "Enjoying a cozy night in with my favorite movies. Sometimes, it's the quiet moments that mean the most. #CozyNight #Relaxation",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Sun Jan 22 09:15:00 +0000 2023",
        "full_text": "Started journaling again. Writing down thoughts and feelings is so therapeutic. #Journaling #SelfCare",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Wed Feb 14 08:50:00 +0000 2023",
        "full_text": "Celebrating love and friendship today. Happy Valentine's Day to all! #ValentinesDay #Love",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Fri Mar 03 16:35:00 +0000 2023",
        "full_text": "Had a great day exploring the city. There are so many hidden gems waiting to be discovered. #CityAdventures #Explore",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Tue Apr 25 11:00:00 +0000 2023",
        "full_text": "Fresh flowers on the table always brighten up the room and my mood. #Flowers #Happiness",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Mon May 29 14:45:00 +0000 2023",
        "full_text": "Spent the afternoon painting. Creative activities are such a great way to unwind. #Art #Creativity",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Thu Jun 22 19:55:00 +0000 2023",
        "full_text": "Movie night under the stars was magical. So grateful for these special moments. #OutdoorMovies #Gratitude",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Wed Jul 26 13:30:00 +0000 2023",
        "full_text": "Feeling accomplished after a productive day. Every small step gets us closer to our goals. #Productivity #Goals",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Sat Aug 19 07:40:00 +0000 2023",
        "full_text": "Started my morning with a run and feel so energized. Exercise is the best way to start the day. #MorningRun #Fitness",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Thu Jan 12 07:10:00 +0000 2023",
        "full_text": "Enjoying a peaceful morning walk. Fresh air and sunshine make everything better. #MorningWalk #Nature",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Fri Feb 03 12:40:00 +0000 2023",
        "full_text": "Baked some homemade cookies today. The smell of fresh cookies always brings a smile. #Baking #Homemade",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Sun Mar 19 15:25:00 +0000 2023",
        "full_text": "Visited a local farmer's market. Supporting local businesses and enjoying fresh produce! #FarmersMarket #SupportLocal",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Tue Apr 04 17:15:00 +0000 2023",
        "full_text": "Spent the afternoon at the beach. The sound of waves is so calming. #BeachDay #Relaxation",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Wed May 10 08:55:00 +0000 2023",
        "full_text": "Grateful for the little things in life. Today, it's the smell of fresh coffee. #Gratitude #SimpleJoys",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Sat Jun 17 16:45:00 +0000 2023",
        "full_text": "Had a wonderful picnic in the park. Sunshine, good food, and great company. #Picnic #GoodTimes",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Mon Jul 24 13:20:00 +0000 2023",
        "full_text": "Learning a new language and loving the challenge. It's amazing how it opens up a new world. #LanguageLearning #Growth",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Fri Aug 11 11:05:00 +0000 2023",
        "full_text": "Celebrating small victories today. Every step forward is worth celebrating. #SmallWins #Positivity",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Sun Sep 17 14:35:00 +0000 2023",
        "full_text": "Reconnecting with old hobbies is so refreshing. Picked up painting again and it feels great. #Hobbies #Creativity",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Thu Oct 05 19:50:00 +0000 2023",
        "full_text": "Enjoying a beautiful sunset. Nature's way of ending the day with a masterpiece. #Sunset #NatureLover",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Tue Nov 14 09:30:00 +0000 2023",
        "full_text": "A day spent with loved ones is a day well spent. Cherish these moments. #FamilyTime #Love",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Fri Dec 22 18:15:00 +0000 2023",
        "full_text": "Wrapping gifts for the holidays. Giving is such a joyous feeling. #HolidaySpirit #Giving",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Sun Jan 21 12:05:00 +0000 2023",
        "full_text": "Starting the week with a fresh perspective and positive vibes. Let's make it great! #MondayMotivation #Positivity",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Wed Feb 07 07:45:00 +0000 2023",
        "full_text": "Had an amazing workout this morning. Feeling strong and ready to conquer the day. #Fitness #HealthyLiving",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Fri Mar 16 15:10:00 +0000 2023",
        "full_text": "Visited a new café today. The coffee was fantastic and the atmosphere even better. #CafeHopping #CoffeeLover",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Tue Apr 24 18:30:00 +0000 2023",
        "full_text": "Spending the evening reading by the fireplace. Cozy and content. #ReadingNook #CozyEvenings",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Thu May 31 11:40:00 +0000 2023",
        "full_text": "Grateful for the support of friends and family. Their encouragement means everything. #SupportSystem #Grateful",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Sat Jun 23 20:25:00 +0000 2023",
        "full_text": "Had a blast at the local fair today. So many fun rides and delicious treats! #FairFun #GoodTimes",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Mon Jul 30 13:55:00 +0000 2023",
        "full_text": "Learning to appreciate the journey, not just the destination. Life is a beautiful adventure. #LifeJourney #Gratitude",
        "lang": "en"
      }
    },
    {
      "tweet": {
        "created_at": "Wed Aug 15 09:20:00 +0000 2023",
        "full_text": "Enjoying a quiet morning with my thoughts and a cup of tea. Peaceful and serene. #MorningRoutine #Peace",
        "lang": "en"
      }
    }
]